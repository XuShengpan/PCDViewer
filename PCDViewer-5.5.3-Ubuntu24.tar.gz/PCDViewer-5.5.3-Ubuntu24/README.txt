PCDViewer 部署包（PCDViewer-5.5.3-Ubuntu24 / Ubuntu 24.04）
构建日期: 2026-11-23
====================================================

【快速开始】
  1) 在本目录执行一次性安装（会同时注册全局命令，并自动安装
     桌面菜单项与图标）：
       ./init_install.sh
  2) 打开一个新终端，输入：
       PCDViewer
     或直接从应用菜单中点击 PCDViewer 图标启动。
  3) 如果桌面菜单项/图标没有生效，可单独重新执行：
       ./scripts/install_desktop_entry.sh
  4) 也可以不安装，直接执行：
       ./scripts/run.sh

【目录说明】
  PCDViewer            主程序
  GroundFilter_dialog  辅助程序
  init_install.sh      一键安装入口（注册全局命令，
                       并自动调用 scripts/install_desktop_entry.sh）
  scripts/             辅助脚本目录
    run.sh               主程序启动脚本（自包含环境变量，已修复相对路径问题）
    run_groundfilter.sh  辅助程序启动脚本（自包含环境变量）
    install_desktop_entry.sh  添加桌面菜单项 + 安装图标
  libs/                运行时依赖库（Qt/PCL/VTK/Boost 等）
  plugins/             Qt 插件（platforms/imageformats/xcbglintegrations）
  openni2/             OpenNI2 驱动
  icons/               图标文件（供桌面菜单项使用）
  test_data/           样例数据

【环境要求】
  - Ubuntu 24.04 x86_64
  - X11 桌面环境（xcb；Wayland 下会走 XWayland）
  - 基础系统库由目标系统提供：glibc 家族、libGL 家族、libusb 等

【图标说明】
  如果桌面菜单里图标显示为空白方块，请依次尝试：
    1) 重新执行 ./scripts/install_desktop_entry.sh
    2) gtk-update-icon-cache -f -t ~/.local/share/icons/hicolor
    3) 注销后重新登录（GNOME 图标缓存有时需要重登）

【卸载】
  rm -f ~/.local/bin/PCDViewer ~/.local/bin/GroundFilter_dialog
  rm -f ~/.local/share/applications/pcdviewer.desktop
  rm -f ~/.local/share/icons/hicolor/*/apps/pcdviewer.*
  update-desktop-database ~/.local/share/applications 2>/dev/null || true

【故障排查】
  在包目录执行:
    LD_LIBRARY_PATH=$PWD/libs ldd ./PCDViewer | grep 'not found'
    LD_LIBRARY_PATH=$PWD/libs ldd ./plugins/platforms/libqxcb.so | grep 'not found'
  如果出现 not found，请把对应库名反馈给开发。
