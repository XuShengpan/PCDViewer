#!/bin/bash
# PCDViewer 启动脚本
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
    DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
SCRIPT_DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
HERE="$(cd -P "$SCRIPT_DIR/.." >/dev/null 2>&1 && pwd)"

# 记录调用者的当前工作目录，用于解析相对路径参数
CALLER_PWD="$PWD"

cd "$HERE" || { echo "无法进入程序目录: $HERE"; exit 1; }

export LD_LIBRARY_PATH="$HERE/libs${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export QT_PLUGIN_PATH="$HERE/plugins"
export QT_QPA_PLATFORM_PLUGIN_PATH="$HERE/plugins/platforms"
export OPENNI2_REDIST="$HERE/openni2"
export OPENNI2_DRIVERS_PATH="$HERE/openni2/Drivers"

export QT_QPA_PLATFORM=xcb
export QT_X11_NO_MITSHM=1
export QT_AUTO_SCREEN_SCALE_FACTOR=0
export QT_IM_MODULE=xim
export XMODIFIERS=@im=none

# 处理用户传入的相对路径参数，将其转换为绝对路径
NEW_ARGS=()
for arg in "$@"; do
    if [[ "$arg" == -* ]]; then
        if [[ "$arg" == --*=* ]]; then
            key="${arg%%=*}"
            val="${arg#*=}"
            if [[ "$val" != /* ]] && [ -e "$CALLER_PWD/$val" ]; then
                NEW_ARGS+=("$key=$CALLER_PWD/$val")
                continue
            fi
        fi
        NEW_ARGS+=("$arg")
    else
        if [[ "$arg" != /* ]] && [ -e "$CALLER_PWD/$arg" ]; then
            NEW_ARGS+=("$CALLER_PWD/$arg")
        else
            NEW_ARGS+=("$arg")
        fi
    fi
done

exec "$HERE/PCDViewer" "${NEW_ARGS[@]}"
