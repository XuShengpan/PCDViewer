#!/bin/bash
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
    DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
SCRIPT_DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
HERE="$(cd -P "$SCRIPT_DIR/.." >/dev/null 2>&1 && pwd)"

APPS="$HOME/.local/share/applications"
mkdir -p "$APPS"

# ---- 1. 寻找包内图标 ----
ICON_SRC=""
for ic in PCDViewer.png pcdviewer.png PCDViewer.svg pcdviewer.svg \
          PCDViewer.ico pcdviewer.ico icon.png Icon.png app.png logo.png; do
    if [ -f "$HERE/icons/$ic" ]; then
        ICON_SRC="$HERE/icons/$ic"
        break
    fi
    if [ -f "$HERE/$ic" ]; then
        ICON_SRC="$HERE/$ic"
        break
    fi
done

ICON_KEY="applications-graphics"
if [ -n "$ICON_SRC" ]; then
    EXT="${ICON_SRC##*.}"
    case "$EXT" in
        svg) ICON_THEME_DIR="$HOME/.local/share/icons/hicolor/scalable/apps" ;;
        png) ICON_THEME_DIR="$HOME/.local/share/icons/hicolor/256x256/apps" ;;
        ico) ICON_THEME_DIR="$HOME/.local/share/icons/hicolor/256x256/apps" ;;
        xpm) ICON_THEME_DIR="$HOME/.local/share/icons/hicolor/48x48/apps" ;;
        *)   ICON_THEME_DIR="$HOME/.local/share/icons/hicolor/256x256/apps" ;;
    esac
    mkdir -p "$ICON_THEME_DIR"
    
    DEST_EXT="$EXT"
    [ "$EXT" = "ico" ] && DEST_EXT="png"
    DEST_FILE="$ICON_THEME_DIR/pcdviewer.$DEST_EXT"

    cp -f "$ICON_SRC" "$DEST_FILE"
    echo "[OK] 已安装图标: $DEST_FILE"
    ICON_KEY="pcdviewer"
else
    echo "[WARN] 包内未找到图标文件，.desktop 将使用系统默认图标名 '$ICON_KEY'"
fi

# ---- 2. 写 .desktop ----
# 注意：Exec 指向包内 scripts/run.sh
cat > "$APPS/pcdviewer.desktop" <<EOF2
[Desktop Entry]
Type=Application
Version=1.0
Name=PCDViewer
GenericName=Point Cloud Viewer
Comment=Point Cloud Data Viewer
Exec=$HERE/scripts/run.sh
TryExec=$HERE/scripts/run.sh
Path=$HERE
Icon=$ICON_KEY
Terminal=false
Categories=Graphics;Science;Engineering;
StartupNotify=true
StartupWMClass=PCDViewer
EOF2
chmod 644 "$APPS/pcdviewer.desktop"

# ---- 3. 刷新缓存 ----
update-desktop-database "$APPS" 2>/dev/null || true
gtk-update-icon-cache -f -t "$HOME/.local/share/icons/hicolor" 2>/dev/null || true

echo "[OK] 已添加桌面菜单项 PCDViewer"
echo "     若菜单中未立即出现，可注销后重新登录，或执行:"
echo "       update-desktop-database ~/.local/share/applications"
echo "       gtk-update-icon-cache -f -t ~/.local/share/icons/hicolor"
