#!/bin/bash
# PCDViewer 一键安装：注册全局命令 + 自动安装桌面菜单项/图标
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
    DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
HERE="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"

echo "======================================"
echo "  PCDViewer 一键安装"
echo "======================================"
echo "包目录: $HERE"
echo

for f in scripts/run.sh PCDViewer libs plugins; do
    if [ ! -e "$HERE/$f" ]; then
        echo "错误: 缺少必要文件 $HERE/$f" >&2
        [ ! -t 0 ] && read -r -p "按回车键关闭..." _
        exit 1
    fi
done

BIN_DIR="$HOME/.local/bin"
mkdir -p "$BIN_DIR" || {
    echo "错误: 无法创建 $BIN_DIR" >&2
    [ ! -t 0 ] && read -r -p "按回车键关闭..." _
    exit 1
}

install_wrapper() {
    local name="$1" target="$2"
    local wrapper="$BIN_DIR/$name"
    cat > "$wrapper" <<WRAPPER_EOF
#!/bin/bash
RUNNER="$target"
if [ ! -x "\$RUNNER" ]; then
    echo "错误: 找不到 \$RUNNER" >&2
    echo "PCDViewer 部署包可能已被移动或删除，请重新运行 init_install.sh。" >&2
    exit 1
fi
exec "\$RUNNER" "\$@"
WRAPPER_EOF
    chmod 755 "$wrapper"
    echo "[OK] 已安装命令: $wrapper"
}

install_wrapper "PCDViewer" "$HERE/scripts/run.sh"
if [ -f "$HERE/scripts/run_groundfilter.sh" ]; then
    install_wrapper "GroundFilter_dialog" "$HERE/scripts/run_groundfilter.sh"
fi

LINE='export PATH="$HOME/.local/bin:$PATH"'
for rc in "$HOME/.bashrc" "$HOME/.profile"; do
    [ -f "$rc" ] || continue
    if ! grep -qsF "$LINE" "$rc"; then
        {
            echo ""
            echo "# Added by PCDViewer installer on $(date +%F)"
            echo "$LINE"
        } >> "$rc"
        echo "[OK] 已把 $BIN_DIR 加入 $rc"
    fi
done
export PATH="$BIN_DIR:$PATH"

# ---- 自动安装桌面菜单项与图标 ----
echo
if [ -f "$HERE/scripts/install_desktop_entry.sh" ]; then
    echo "[STEP] 自动安装桌面菜单项与图标..."
    if bash "$HERE/scripts/install_desktop_entry.sh"; then
        echo "[OK] 桌面菜单项与图标安装完成"
    else
        echo "[WARN] 桌面菜单项安装失败（不影响命令行使用）"
        echo "       可稍后手动执行: $HERE/scripts/install_desktop_entry.sh"
    fi
else
    echo "[WARN] 未找到 scripts/install_desktop_entry.sh，跳过桌面菜单项安装"
fi

echo
echo "======================================"
echo "  安装完成！"
echo "======================================"
echo "使用方法："
echo "  打开新终端，输入: PCDViewer"
echo "  或当前终端执行: source ~/.bashrc && PCDViewer"
echo "  也可以从应用菜单中点击 PCDViewer 图标启动"
echo
echo "卸载：rm -f $BIN_DIR/PCDViewer $BIN_DIR/GroundFilter_dialog"
echo
echo "如需重新安装桌面菜单项/图标："
echo "  $HERE/scripts/install_desktop_entry.sh"
echo

if [ ! -t 0 ]; then
    echo "按回车键关闭此窗口..."
    read -r _
fi
