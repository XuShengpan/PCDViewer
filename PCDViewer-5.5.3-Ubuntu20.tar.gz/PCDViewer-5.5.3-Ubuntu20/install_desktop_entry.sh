#!/bin/bash
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
    DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
HERE="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"

APPS="$HOME/.local/share/applications"
mkdir -p "$APPS"

# ---- 1. 寻找包内图标 ----
ICON_SRC=""
for ic in PCDViewer.png pcdviewer.png PCDViewer.svg pcdviewer.svg \
          PCDViewer.ico pcdviewer.ico icon.png Icon.png app.png logo.png; do
    if [ -f "$HERE/icons/$ic" ]; then
        ICON_SRC="$HERE/icons/$ic"
        break
    fi
    if [ -f "$HERE/$ic" ]; then
        ICON_SRC="$HERE/$ic"
        break
    fi
done

ICON_KEY="applications-graphics"   # 兜底：GNOME 通用图形应用图标
if [ -n "$ICON_SRC" ]; then
    EXT="${ICON_SRC##*.}"
    # 按扩展名选择图标目录
    case "$EXT" in
        svg) ICON_THEME_DIR="$HOME/.local/share/icons/hicolor/scalable/apps" ;;
        png) ICON_THEME_DIR="$HOME/.local/share/icons/hicolor/256x256/apps" ;;
        ico) ICON_THEME_DIR="$HOME/.local/share/icons/hicolor/256x256/apps" ;;
        xpm) ICON_THEME_DIR="$HOME/.local/share/icons/hicolor/48x48/apps" ;;
        *)   ICON_THEME_DIR="$HOME/.local/share/icons/hicolor/256x256/apps" ;;
    esac
    mkdir -p "$ICON_THEME_DIR"
    
    # .ico 在部分环境下 GNOME 不能直接识别，统一改名为 .png 存档
    DEST_EXT="$EXT"
    [ "$EXT" = "ico" ] && DEST_EXT="png"
    DEST_FILE="$ICON_THEME_DIR/pcdviewer.$DEST_EXT"

    # 原样拷贝，不做强制缩放
    cp -f "$ICON_SRC" "$DEST_FILE"
    echo "[OK] 已安装图标: $DEST_FILE"
    ICON_KEY="pcdviewer"
else
    echo "[WARN] 包内未找到图标文件，.desktop 将使用系统默认图标名 '$ICON_KEY'"
fi

# ---- 2. 写 .desktop ----
cat > "$APPS/pcdviewer.desktop" <<EOF2
[Desktop Entry]
Type=Application
Version=1.0
Name=PCDViewer
GenericName=Point Cloud Viewer
Comment=Point Cloud Data Viewer
Exec=$HERE/run.sh
TryExec=$HERE/run.sh
Path=$HERE
Icon=$ICON_KEY
Terminal=false
Categories=Graphics;Science;Engineering;
StartupNotify=true
StartupWMClass=PCDViewer
EOF2
chmod 644 "$APPS/pcdviewer.desktop"

# ---- 3. 刷新缓存 ----
update-desktop-database "$APPS" 2>/dev/null || true
gtk-update-icon-cache -f -t "$HOME/.local/share/icons/hicolor" 2>/dev/null || true

echo "[OK] 已添加桌面菜单项 PCDViewer"
echo "     若菜单中未立即出现，可注销后重新登录，或执行:"
echo "       update-desktop-database ~/.local/share/applications"
echo "       gtk-update-icon-cache -f -t ~/.local/share/icons/hicolor"
