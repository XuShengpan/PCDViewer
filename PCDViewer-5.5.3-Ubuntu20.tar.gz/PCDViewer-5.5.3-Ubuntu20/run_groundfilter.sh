#!/bin/bash
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
    DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
HERE="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
cd "$HERE" || exit 1

export LD_LIBRARY_PATH="$HERE/libs${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export QT_PLUGIN_PATH="$HERE/plugins"
export QT_QPA_PLATFORM_PLUGIN_PATH="$HERE/plugins/platforms"
export OPENNI2_REDIST="$HERE/openni2"
export OPENNI2_DRIVERS_PATH="$HERE/openni2/Drivers"
export QT_QPA_PLATFORM=xcb
export QT_X11_NO_MITSHM=1
export QT_IM_MODULE=xim

exec "$HERE/GroundFilter_dialog" "$@"
